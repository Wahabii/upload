const ejs = require('ejs');
const gfs=require('gfs');
const bodyParser = require('body-parser');
const multer= require('multer');
const path=require('path');
//const Joi = require('joi');
const fs = require('fs');
//generate the files names 
const crypto=require('crypto');
const GridFsStorage = require('multer-gridfs-storage');
const Grid = require('gridfs-stream');
const methodeOverride = require('method-override');
const mongoose=require('mongoose');

//web server
const express=require('express');
app=express();

//middleware
app.use(bodyParser.json());
app.use(methodeOverride('_method'));
// mongo URI
 const mongoURI = 'mongodb://localhost/playground';
//create mongo connection 
const conn = mongoose.createConnection(mongoURI);
//init gfs 
conn.once('open', ()=> {
//init stream
 gfs = Grid(conn.db, mongoose.mongo);
 gfs.collection('uploads');
})
//create storage engine 
const storage = new GridFsStorage({
    url: mongoURI,
    file: (req, file) => {
      return new Promise((resolve, reject) => {
        crypto.randomBytes(16, (err, buf) => {
          if (err) {
            return reject(err);
          }
          const filename = buf.toString('hex') + path.extname(file.originalname);
          const fileInfo = {
            filename: filename,
            bucketName: 'uploads'
          };
          resolve(fileInfo);
        });
      });
    }
  });
  const upload = multer({ storage });
  
  app.set('view engine','ejs');

  app.use(express.json());
  //connected to mongodb
  mongoose.connect('mongodb://localhost/playground', { useNewUrlParser: true } )
  .then(() => console.log('login success.. '))
  .catch((err)=> console.log(err));
  
//@router GET
app.get('/', function(req , res){
res.render('acceuil');
});

/*
app.get('/',function (req,res){
res.send('welcome to heroku');
});
*/
//@router GET files
app.get('/files', (req,res)=>{
gfs.files.find().toArray((err,files)=>{
//check if files 
if (!files || files.length===0){
return res.status(404).json({
err:'no files exist'
});
}
//files exist
return res.json(files);
});
});
//@router GET /files /:filename
app.get('/files/:filename', (req,res)=>{
gfs.files.findOne({filename:req.params.filename}, (err,files)=>{
//check if files 
if (!files || files.length===0){
return res.status(404).json({
err:'no files exist'
});
}
//file existe
return res.json(files);
})
});
//@router GET /image /:filename
app.get('/image/:filename', (req,res)=>{
gfs.files.findOne({filename:req.params.filename}, (err,files)=>{
//check if files 
if (!files || files.length===0){
return res.status(404).json({
err:'no files exist'
});
}
// check if image
if(files.contentType === 'image/jpeg' || files.contentType === 'img/png'){
//read output to browser 
const readstream = gfs.createReadStream(files.filename);
readstream.pipe(res);
}
else{
res.status(404).json({
err:'not is image'
});
}
});
});
    
const port=process.env.PORT|| 4000;

app.listen(port);